
library(ggplot2) # Create Elegant Data Visualisations Using the Grammar of Graphics
library(aplot) # Decorate a 'ggplot' with Associated Information
library(dplyr) #
df_map <- map_data("world")
site <- read.csv("s33.csv")


p <- ggplot() +
  # 世界地图底图
  geom_polygon(
    data = df_map,
    aes(long, lat, group = group),
    fill = "grey90"
  ) +
  # 采样点图层（统一填充色）
  geom_point(
    data = site,
    mapping = aes(Long, lat),  # 移除fill=group
    fill = "#7bbc5c",          # 固定填充色
    size = 3,
    color = "white",
    shape = 21,
    alpha = 0.9,
    stroke = 0.4,
    show.legend = FALSE        # 隐藏单色图例
  ) +
  # 坐标轴与主题
  theme_bw() +
  theme(
    axis.text = element_text(size = 10, color = "black"),
    axis.title.x = element_text(size = 12, color = "black", hjust = 0.5),
    axis.title.y = element_text(size = 12, color = "black", hjust = 0.5),
    plot.background = element_rect(fill = "white")
  ) +
  # 坐标轴设置
  scale_y_continuous(expand = c(0, 0), position = "left") +
  scale_x_continuous(expand = c(0, 0), position = "bottom") +
  # 轴标题
  labs(x = "Longitude", y = "Latitude")

p

library(ggforce)
p_main <- p + 
  annotate("rect", xmin=80, xmax=140, ymin=15, ymax=50, 
           color="black", fill=NA, size=0.8) 

p_main 
ggsave("glo.pdf",p_main,width = 12,height = 8)
p_zoom <- p + 
  coord_cartesian(xlim=c(80,140), ylim=c(15,50)) +  # 直接缩放坐标
  theme(panel.border = element_rect(color="black", fill=NA))
p_zoom

ggsave("china.pdf",p_zoom,width = 6,height = 4)
