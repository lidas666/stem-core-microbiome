

library(psych)
library(reshape2)

fu<-read.csv("heatmap.csv",row.names = 1)
fu<-fu[1:6]
fu1<-as.data.frame(t(fu))

otu2<-fu

b<-rcorr(t(otu2),type="spearman")
rr<-b$r
pp<-b$P
rr[abs(rr)<0.6]<-0
pp<-p.adjust(pp,method="BH")
pp[pp>=0.05&pp<1]<-0  
pp[pp<0.05]<-1
z<-rr*pp
diag(z)<-0
#z1<-abs(z)
g<-graph.adjacency(z,weighted=TRUE,mode="undirected")
g  

g <- graph_from_adjacency_matrix(as.matrix(z), mode = 'undirected', weighted=TRUE, diag = FALSE)
g
V(g)$degree<-igraph::degree(g)

soil<-g
soil1<-data.frame(igraph::as_data_frame(soil, what = "both")$edges)
soil2<-data.frame(igraph::as_data_frame(soil, what = "both")$vertices)
write.csv(soil1,"edg_gene.csv")
write.csv(soil2,"node_gene.csv")


save(g,file = 'networkrgene.rda')
load('networkrgene.rda')


g1 <- g

pdf(paste0("negene.pdf"), encoding="MacRoman", width=8, height=8)

new_colors <- c("#7bbc5c")

V(g1)$col <- new_colors
E(g1)$weight1<-E(g1)$weight
E(g1)$weight<-abs(E(g1)$weight)
E(g1)$linetype <-ifelse(E(g1)$weight1 > 0, "positive", "negative")
E(g1)$color <- ifelse(E(g1)$linetype == "positive","#c62d17",rgb(0,147,0,maxColorValue = 255))
layout1 <- layout_in_circle(g1)
layout2 <- layout_with_fr(g1) 
layout3 <- layout_(g1,with_fr(niter=999, grid="nogrid"))
alpha <- 0.8 
edge_alpha <- alpha * abs(E(g1)$weight)

plot.igraph(g1, layout=layout1,
            vertex.color=V(g1)$col,
            shape = 1,
            vertex.size=V(g1)$degree*2, 
            rescale =TRUE, 
            vertex.label=V(g1)$label,
            vertex.label.dist = 3,
            edge.arrow.size=0.2,
            edge.width=abs(E(g1)$weight)*3,
            edge.curved = TRUE,
            edge.alpha = edge_alpha
)

legend(
  title = "|r-value|",
  list(x = min(layout1[,1])+0.4,
       y = min(layout1[,2])-0.17),
  legend = c(0.6,0.8,1.0),
  col = "black",
  lty=1,
  lwd=c(0.6,0.8,1.0)*2,
)
legend(
  title = "Correlation (±)",
  list(x = min(layout1[,1])+0.8,
       y = min(layout1[,2])-0.17),
  legend = c("positive","negative"),
  col = c("red",rgb(0,147,0,maxColorValue = 255)),
  lty=1,
  lwd=1
)
legend(
  title = "Degree",
  list(x = min(layout1[,1])+1.2,
       y = min(layout1[,2])-0.17),
  legend = c(1,seq(0,16,3)[-1]),
  col = "black",
  pch=1,
  pt.lwd=1,
  pt.cex=c(1,seq(0,8,2)[-1])
)
dev.off()

