

library(ggplot2)
library(reshape2)
library(vegan)
library(ape)
library(picante) 
library(dplyr)
library(ggpubr)
library(car)
library(MuMIn) 
library(lmerTest)

alpha <- function(x, tree = NULL, base = exp(1)) {
  est <- estimateR(x)
  Richness <- est[1, ]
  Chao1 <- est[2, ]
  ACE <- est[4, ]
  Shannon <- diversity(x, index = 'shannon', base = base)
  Simpson <- diversity(x, index = 'simpson')   
  Pielou <- Shannon / log(Richness, base)
  goods_coverage <- 1 - rowSums(x == 1) / rowSums(x)
  
  result <- data.frame(Richness, Shannon, Simpson, Pielou, Chao1, ACE, goods_coverage)
  if (!is.null(tree)) {
    PD_whole_tree <- pd(x, tree, include.root = FALSE)[1]
    names(PD_whole_tree) <- 'PD_whole_tree'
    result <- cbind(result, PD_whole_tree)
  }
  result
}

otu <- read.csv("Bacteria ZOTU table.csv",sep = ",",row.names = 1)
otu <-t(otu)
alpha_all <- alpha(otu, base = 2)
write.csv(alpha_all, 'Bacteria alpha diversity.csv', quote = FALSE)


alpha_all$SampleID<-row.names(alpha_all)
names(alpha_all)[8]<-c("SampleID")
gro<-read.csv("Group.csv",sep = ",")
da<-merge(gro,alpha_all,by="SampleID")
da <- da %>% 
  filter(State != "Soil")

da1 <- da %>% 
  filter(Compartment == "Rhizosphere")


shapiro<-shapiro.test(da1$Richness)
shapiro
var<- var.test(Richness~State,data=da1)
var
####################Fig1B
p1<-ggplot(data=da, aes(x = State, y = Richness,
                        color=State)) +
  geom_boxplot(alpha =0.5,size=1,outlier.shape = NA)+
  scale_color_manual(limits=c("Healthy","Diseased"), 
                     values=c("#203378","#e3bf2b"))+
  stat_compare_means(method = "wilcox.test",paired = F, 
                     comparisons=list(c("Healthy","Diseased")))+
  geom_jitter(size=0.5)+
scale_y_continuous(expand = expansion(mult = c(0.05, 0.1)))+
  facet_wrap(~Compartment, ncol=4)+
  theme_bw(base_size = 16) +
  theme(axis.ticks.length = unit(0.4,"lines"), axis.ticks = element_line(color='black'),
        axis.line = element_line(colour = "black"), 
        axis.title.x=element_text(colour='black', size=20,vjust = 1.5),
        axis.title.y=element_text(colour='black', size=20,vjust = 1.5),#face = "bold"),
        axis.text.y=element_text(colour='black',size=18),#face = "bold"),
        axis.text.x=element_text(colour='black',size=18,angle = 90,hjust = 1),
        strip.text = element_text(colour = "black",size = 15,face = "bold"),
        legend.position = 'right')+
  labs(y='Bacteria richness')
p1
ggsave("Fig1B Bacteria.pdf",p1,width = 7,height = 4)


################################Linear Mixed Effects Model
library(nlme)
library(glmm.hp)
 alp <- da 
div.fit2 <- lme(Richness ~ Site + Compartment + State, random = ~1 | group, data = alp)
summary(div.fit2)
anova(div.fit2)
c<-anova(div.fit2)
c<-c[-1,]
a<-glmm.hp(div.fit2)
b<-a$hierarchical.partitioning

d<-cbind(c,b)
d$ID<-row.names(d)
write.csv(d,"BacteriaLMM_wh.csv")
p2 <- ggplot(d, aes(ID, Unique* 100, fill = ID)) +
  geom_bar(stat = 'identity', position = 'fill', width =0.3) + 
  geom_col(width =0.7) +
  labs(x ='R2 =0.8360057', y = 'LMM R2')+ 
  scale_fill_manual(values = c('#F46444','#DE820D','#AFE1AE'))+
  theme_bw(base_size = 16) +
  theme(axis.ticks.length = unit(0.4,"lines"), axis.ticks = element_line(color='black'),
        axis.line = element_line(colour = "black"), 
        axis.title.x=element_text(colour='black', size=20,vjust = 1.5),
        axis.title.y=element_text(colour='black', size=20,vjust = 1.5),#face = "bold"),
        axis.text.y=element_text(colour='black',size=18),#face = "bold"),
        axis.text.x=element_text(colour='black',size=18),
        strip.text = element_text(colour = "black",size = 15,face = "bold"),
        legend.position = 'right')+
  geom_text(aes(label = sprintf("P = %.3f", `p-value`), y = Unique * 100 + 5), 
            size = 4, 
            vjust = 0)
p2
ggsave("BacteriaLMM_wh.pdf",p2,width = 6,height = 4)



##########rhizosphere
da1 <- da %>% 
  filter(Compartment == "Rhizosphere")
alp<-da1
Rh.fit2 <- lme(Richness ~ Site +  State, random = ~1 | group, data = alp)
summary(Rh.fit2)
anova(Rh.fit2)
c<-anova(Rh.fit2)
c<-c[-1,]
a<-glmm.hp(Rh.fit2)
b<-a$hierarchical.partitioning
rh<-cbind(c,b)
rh$Compartment<-c("Rhizosphere")
##########Root
da1 <- da %>% 
  filter(Compartment == "Root")
alp<-da1
Rh.fit2 <- lme(Richness ~ Site +  State, random = ~1 | group, data = alp)
summary(Rh.fit2)
anova(Rh.fit2)
c<-anova(Rh.fit2)
c<-c[-1,]
a<-glmm.hp(Rh.fit2)
b<-a$hierarchical.partitioning
ro<-cbind(c,b)
ro$Compartment<-c("Root")

##########Stem
da1 <- da %>% 
  filter(Compartment == "Stem")
alp<-da1
Rh.fit2 <- lme(Richness ~ Site +  State, random = ~1 | group, data = alp)
summary(Rh.fit2)
anova(Rh.fit2)
c<-anova(Rh.fit2)
c<-c[-1,]
a<-glmm.hp(Rh.fit2)
b<-a$hierarchical.partitioning
st<-cbind(c,b)
st$Compartment<-c("Stem")

##########Seed
da1 <- da %>% 
  filter(Compartment == "Seed")
alp<-da1
Rh.fit2 <- lme(Richness ~ Site +  State, random = ~1 | group, data = alp)
summary(Rh.fit2)
anova(Rh.fit2)
c<-anova(Rh.fit2)
c<-c[-1,]
a<-glmm.hp(Rh.fit2)
b<-a$hierarchical.partitioning
se<-cbind(c,b)
se$Compartment<-c("Seed")

wh<-rbind(rh,ro,st,se)
wh$group<-row.names(wh)

write.csv(wh,"BacteriaLMM_Div1.csv")
p3<- ggplot(wh, aes(group, Unique* 100, fill = Compartment)) +
  geom_bar(stat = 'identity', position = 'fill', width =0.3) + 
  geom_col(width =0.7) +
  labs(x ='', y = 'LMM R2')+ 
  scale_fill_manual(values = c("#F57E21","#6989b9","#a9c1a3","#69A040"))+
  theme_classic() +
 scale_y_continuous(limits = c(-5, 100),expand = c(0,0))+ 
  theme_bw(base_size = 16) +
  theme(axis.ticks.length = unit(0.4,"lines"), axis.ticks = element_line(color='black'),
        axis.line = element_line(colour = "black"), 
        axis.title.x=element_text(colour='black', size=20,vjust = 1.5),
        axis.title.y=element_text(colour='black', size=20,vjust = 1.5),#face = "bold"),
        axis.text.y=element_text(colour='black',size=18),#face = "bold"),
        axis.text.x=element_text(colour='black',size=18),
        strip.text = element_text(colour = "black",size = 15,face = "bold"),
        legend.position = 'right')+
  geom_text(aes(label = sprintf("P = %.3f", `p-value`), y = Unique * 100 + 5), 
            size = 3, 
            vjust = 0)
p3
ggsave("BacteriaLMM_Div1.pdf",p3,width = 7,height = 4)

################################################Relative abundance

otu <- t(read.csv("Bacteria ZOTU table.csv", row.names=1,check.names = F)) 
otu_r <- decostand(otu,"total", MARGIN=2)
otu_r=t(otu_r)
write.csv(otu_r, 'Bacteria relative abundance.csv', row.names = T)

#####################################################Fig1D
otu <- read.csv("Bacteria relative abundance.csv",sep = ",",row.names = 1)
otu <- data.frame(t(otu))
write.csv(otu,"t_wr.csv")
group<-read.csv("Group.csv",sep = ",")
otu <- read.csv("nosoil_wr.csv",sep = ",",row.names = 1)
otu <- data.frame(t(otu))
library(dplyr)
group <- group %>% 
  filter(State != "Soil")
dis1 <- vegdist(otu1, method = 'bray')
adonis_result <- adonis2(dis1~Compartment+Site+State, group, permutations = 999)
summary(adonis_result)
adonis_result$R2
adonis_result$`Pr(>F)`

pcoa <- cmdscale(dis1, k = (nrow(otu) - 1), eig = TRUE)
ordiplot(scores(pcoa)[ ,c(1, 2)], type = 't')

summary(pcoa)

point <- data.frame(pcoa$point)  

pcoa_eig <- (pcoa$eig)[1:2] / sum(pcoa$eig)

sample_site <- data.frame({pcoa$point})[1:2]
sample_site$SampleID <- rownames(sample_site)
names(sample_site)[1:2] <- c('PCoA1', 'PCoA2')

sample_site <- merge(sample_site, group, by = 'SampleID', all.x = TRUE)

library(dplyr)
sample_site <- sample_site %>% 
  filter(State != "Soil")
sample_site$Compartment <- factor(sample_site$Compartment, levels = c('Rhizosphere',"Root" ,"Stem" ,"Seed" ))
sample_site$State<- factor(sample_site$State, levels = c('Healthy','Diseased'))

cbbPalette <- c("#203378","#6989b9","#a9c1a3","#e3bf2b")

p1<- ggplot(sample_site, aes(PCoA1, PCoA2, group = Compartment)) +
  geom_point(aes(color = Compartment,shape =State), size = 3, alpha = 1)+
  scale_color_manual(values = cbbPalette) +
  geom_vline(aes(xintercept = 0),linetype="dotted")+
  geom_hline(aes(yintercept = 0),linetype="dotted")+
  theme(panel.background = element_rect(fill='white', colour='black'),
        panel.grid=element_blank())+
  labs(x = paste('PCoA 1: ', round(100 * pcoa_eig[1], 2), '%'), y = paste('PCoA 2: ', round(100 * pcoa_eig[2], 2), '%'))+
  theme_bw()+
  theme(axis.ticks.length = unit(0.4,"lines"), axis.ticks = element_line(color='black'),
        axis.line = element_line(colour = "black"), 
        axis.title.x=element_text(colour='black', size=18,vjust = 1.5),
        axis.title.y=element_text(colour='black', size=18,vjust = 1.5),
        axis.text.y=element_text(colour='black',size=15),
        axis.text.x=element_text(colour = "black",size = 15,
                                 hjust = 1,vjust = 0.5))+
  stat_ellipse(aes(color = Compartment), level = 0.95, linetype = 6, show.legend = FALSE)+
  annotate("text",-0.30,0.52,label = "Site:R2=0.1076** 
     Compartment:R2=0.078**  
     Site:R2=0.0013**",size=5)
p1
ggsave("BacteriaPCoa.pdf",p1,width = 7,height = 7)


##############################################divide test
otu <- read.csv("t_wr.csv",sep = ",")
names(otu)[1]<-c("SampleID")
group<-read.delim("Group.csv")
aa<-merge(otu,group,by="SampleID")
library(dplyr)
aa <- aa %>% 
  filter(State != "Soil")
data_list <- split(aa, aa$Compartment)
df_split <- data_list
for (i in seq_along(df_split)) {
  filename <- paste0(names(df_split)[i], ".csv") 
  write.csv(df_split[[i]], file = filename, row.names = F) 
}


file_names <- list.files(pattern = "*.csv")
transpose_csv <- function(file_name) {
  data <- read.csv(file_name)
  transposed_data <- t(data)
  transposed_data<-transposed_data[-40307:-40312,]
  colnames(transposed_data)<-transposed_data[1,]
  transposed_data<-transposed_data[-1,]
  write.csv(transposed_data, file_name, row.names = T)
}
lapply(file_names, transpose_csv)

for (file_name in file_names) {
  data <- t(read.csv(file_name, header = T))
  colnames(data) <- data[1,]
  data <- data[-1,] 
  data <- cbind(SampleID = rownames(data), data)
  rownames(data) <- NULL
  group<-read.delim("Group.txt")
  group<-merge(group,data,by="SampleID")
  group<-group[1:4]
  data <- t(read.csv(file_name, header = T,row.names = 1))
  dist_mat <- vegdist(data,method = 'bray')
  result <-adonis2(dist_mat ~Site+State,group, permutations = 99)
  cat(paste("File name: ", file_name, "\n"))
  print(result)
  data.frame()
  write.csv(data.frame(result$R2,result$`Pr(>F)`) ,paste0(file_name, ".", file_name, "_adonis_result.csv"))
}

#######################Fig1F Bacteria
p<-ggplot(aa, aes(x = Compartment, y = R2, fill = group))+
  geom_bar(stat = "identity", width = 0.7)+
  geom_flow(aes(alluvium = group), alpha = 0.5) + 
  scale_fill_manual(values = c("#FF5900","#187c65"))+
  theme_bw()+ 
  xlab("Compartment")+
  ylab("PERMANOVA R2")+ 
  theme_bw()+
  theme(axis.ticks.length = unit(0.4,"lines"), axis.ticks = element_line(color='black'),
        axis.line = element_line(colour = "black"), 
        axis.title.x=element_text(colour='black', size=18,vjust = 1.5),
        axis.title.y=element_text(colour='black', size=18,vjust = 1.5),
        axis.text.y=element_text(colour='black',size=15),
        axis.text.x=element_text(colour = "black",size = 15,
                                 hjust = 1,vjust = 1,angle = (0))) 


################################Fungi
rm(list = ls())
setwd("F:/博士/博士/文章撰写/茎部核心微生物组抗病/原始数据与绘图代码/Fig1")
getwd()

library(ggplot2)
library(reshape2)
library(vegan)
library(ape)
library(picante) 
library(dplyr)
library(ggpubr)
library(car)
library(MuMIn) 
library(lmerTest)

alpha <- function(x, tree = NULL, base = exp(1)) {
  est <- estimateR(x)
  Richness <- est[1, ]
  Chao1 <- est[2, ]
  ACE <- est[4, ]
  Shannon <- diversity(x, index = 'shannon', base = base)
  Simpson <- diversity(x, index = 'simpson')   
  Pielou <- Shannon / log(Richness, base)
  goods_coverage <- 1 - rowSums(x == 1) / rowSums(x)
  
  result <- data.frame(Richness, Shannon, Simpson, Pielou, Chao1, ACE, goods_coverage)
  if (!is.null(tree)) {
    PD_whole_tree <- pd(x, tree, include.root = FALSE)[1]
    names(PD_whole_tree) <- 'PD_whole_tree'
    result <- cbind(result, PD_whole_tree)
  }
  result
}

otu <- read.csv("Fungi ZOTU table.csv",sep = ",",row.names = 1)
otu <-t(otu)
alpha_all <- alpha(otu, base = 2)
write.csv(alpha_all, 'Fungi alpha diversity.csv', quote = FALSE)


alpha_all$SampleID<-row.names(alpha_all)
names(alpha_all)[8]<-c("SampleID")
gro<-read.csv("Group.csv",sep = ",")
da<-merge(gro,alpha_all,by="SampleID")
da <- da %>% 
  filter(State != "Soil")

da1 <- da %>% 
  filter(Compartment == "Rhizosphere")


shapiro<-shapiro.test(da1$Richness)
shapiro
var<- var.test(Richness~State,data=da1)
var
####################Fig1C
p1<-ggplot(data=da, aes(x = State, y = Richness,
                        color=State)) +
  geom_boxplot(alpha =0.5,size=1,outlier.shape = NA)+
  scale_color_manual(limits=c("Healthy","Diseased"), 
                     values=c("#203378","#e3bf2b"))+
  stat_compare_means(method = "wilcox.test",paired = F, 
                     comparisons=list(c("Healthy","Diseased")))+
  geom_jitter(size=0.5)+
  scale_y_continuous(expand = expansion(mult = c(0.05, 0.1)))+
  facet_wrap(~Compartment, ncol=4)+
  theme_bw(base_size = 16) +
  theme(axis.ticks.length = unit(0.4,"lines"), axis.ticks = element_line(color='black'),
        axis.line = element_line(colour = "black"), 
        axis.title.x=element_text(colour='black', size=20,vjust = 1.5),
        axis.title.y=element_text(colour='black', size=20,vjust = 1.5),#face = "bold"),
        axis.text.y=element_text(colour='black',size=18),#face = "bold"),
        axis.text.x=element_text(colour='black',size=18,angle = 90,hjust = 1),
        strip.text = element_text(colour = "black",size = 15,face = "bold"),
        legend.position = 'right')+
  labs(y='Fungi richness')
p1
ggsave("Fig1C Fungi.pdf",p1,width = 7,height = 4)


################################Linear Mixed Effects Model
library(nlme)
library(glmm.hp)
alp <- da 
div.fit2 <- lme(Richness ~ Site + Compartment + State, random = ~1 | group, data = alp)
summary(div.fit2)
anova(div.fit2)
c<-anova(div.fit2)
c<-c[-1,]
a<-glmm.hp(div.fit2)
b<-a$hierarchical.partitioning

d<-cbind(c,b)
d$ID<-row.names(d)
write.csv(d,"FungiLMM_wh.csv")
p2 <- ggplot(d, aes(ID, Unique* 100, fill = ID)) +
  geom_bar(stat = 'identity', position = 'fill', width =0.3) + 
  geom_col(width =0.7) +
  labs(x ='', y = 'LMM R2')+ 
  scale_fill_manual(values = c('#F46444','#DE820D','#AFE1AE'))+
  theme_bw(base_size = 16) +
  theme(axis.ticks.length = unit(0.4,"lines"), axis.ticks = element_line(color='black'),
        axis.line = element_line(colour = "black"), 
        axis.title.x=element_text(colour='black', size=20,vjust = 1.5),
        axis.title.y=element_text(colour='black', size=20,vjust = 1.5),#face = "bold"),
        axis.text.y=element_text(colour='black',size=18),#face = "bold"),
        axis.text.x=element_text(colour='black',size=18),
        strip.text = element_text(colour = "black",size = 15,face = "bold"),
        legend.position = 'right')+
  geom_text(aes(label = sprintf("P = %.3f", `p-value`), y = Unique * 100 + 5), 
            size = 4, 
            vjust = 0)
p2
ggsave("FungiLMM_wh.pdf",p2,width = 6,height = 4)



##########rhizosphere
da1 <- da %>% 
  filter(Compartment == "Rhizosphere")
alp<-da1
Rh.fit2 <- lme(Richness ~ Site +  State, random = ~1 | group, data = alp)
summary(Rh.fit2)
anova(Rh.fit2)
c<-anova(Rh.fit2)
c<-c[-1,]
a<-glmm.hp(Rh.fit2)
b<-a$hierarchical.partitioning
rh<-cbind(c,b)
rh$Compartment<-c("Rhizosphere")
##########Root
da1 <- da %>% 
  filter(Compartment == "Root")
alp<-da1
Rh.fit2 <- lme(Richness ~ Site +  State, random = ~1 | group, data = alp)
summary(Rh.fit2)
anova(Rh.fit2)
c<-anova(Rh.fit2)
c<-c[-1,]
a<-glmm.hp(Rh.fit2)
b<-a$hierarchical.partitioning
ro<-cbind(c,b)
ro$Compartment<-c("Root")



##########Stem
da1 <- da %>% 
  filter(Compartment == "Stem")
alp<-da1
Rh.fit2 <- lme(Richness ~ Site +  State, random = ~1 | group, data = alp)
summary(Rh.fit2)
anova(Rh.fit2)
c<-anova(Rh.fit2)
c<-c[-1,]
a<-glmm.hp(Rh.fit2)
b<-a$hierarchical.partitioning
st<-cbind(c,b)
st$Compartment<-c("Stem")

##########Seed
da1 <- da %>% 
  filter(Compartment == "Seed")
alp<-da1
Rh.fit2 <- lme(Richness ~ Site +  State, random = ~1 | group, data = alp)
summary(Rh.fit2)
anova(Rh.fit2)
c<-anova(Rh.fit2)
c<-c[-1,]
a<-glmm.hp(Rh.fit2)
b<-a$hierarchical.partitioning
se<-cbind(c,b)
se$Compartment<-c("Seed")

wh<-rbind(rh,ro,st,se)
wh$group<-row.names(wh)

write.csv(wh,"FungiLMM_Div1.csv")
p3<- ggplot(wh, aes(group, Unique* 100, fill = Compartment)) +
  geom_bar(stat = 'identity', position = 'fill', width =0.3) + 
  geom_col(width =0.7) +
  labs(x ='', y = 'LMM R2')+ 
  scale_fill_manual(values = c("#F57E21","#6989b9","#a9c1a3","#69A040"))+
  theme_classic() +
  scale_y_continuous(limits = c(-5, 100),expand = c(0,0))+ 
  theme_bw(base_size = 16) +
  theme(axis.ticks.length = unit(0.4,"lines"), axis.ticks = element_line(color='black'),
        axis.line = element_line(colour = "black"), 
        axis.title.x=element_text(colour='black', size=20,vjust = 1.5),
        axis.title.y=element_text(colour='black', size=20,vjust = 1.5),#face = "bold"),
        axis.text.y=element_text(colour='black',size=18),#face = "bold"),
        axis.text.x=element_text(colour='black',size=18),
        strip.text = element_text(colour = "black",size = 15,face = "bold"),
        legend.position = 'right')+
  geom_text(aes(label = sprintf("P = %.3f", `p-value`), y = Unique * 100 + 5), 
            size = 3, 
            vjust = 0)
p3
ggsave("FungiLMM_Div1.pdf",p3,width = 7,height = 4)

################################################Relative abundance

otu <- t(read.csv("Fungi ZOTU table.csv", row.names=1,check.names = F)) 
otu_r <- decostand(otu,"total", MARGIN=2)
otu_r <- otu/rowSums(otu)
otu_r=t(otu_r)
write.csv(otu_r, 'Fungi relative abundance.csv', row.names = T)

#####################################################Fig1D
otu <- read.csv("Fungi relative abundance.csv",sep = ",",row.names = 1)
otu <- data.frame(t(otu))
write.csv(otu,"t_wr.csv")
group<-read.csv("Group.csv",sep = ",")
otu <- read.csv("nosoil_wr.csv",sep = ",",row.names = 1)
otu <- data.frame(t(otu))
library(dplyr)
group <- group %>% 
  filter(State != "Soil")
dis1 <- vegdist(otu1, method = 'bray')
adonis_result <- adonis2(dis1~Compartment+Site+State, group, permutations = 999)
summary(adonis_result)
adonis_result$R2
adonis_result$`Pr(>F)`

pcoa <- cmdscale(dis1, k = (nrow(otu) - 1), eig = TRUE)
ordiplot(scores(pcoa)[ ,c(1, 2)], type = 't')

summary(pcoa)

point <- data.frame(pcoa$point)  

pcoa_eig <- (pcoa$eig)[1:2] / sum(pcoa$eig)

sample_site <- data.frame({pcoa$point})[1:2]
sample_site$SampleID <- rownames(sample_site)
names(sample_site)[1:2] <- c('PCoA1', 'PCoA2')

sample_site <- merge(sample_site, group, by = 'SampleID', all.x = TRUE)

library(dplyr)
sample_site <- sample_site %>% 
  filter(State != "Soil")
sample_site$Compartment <- factor(sample_site$Compartment, levels = c('Rhizosphere',"Root" ,"Stem" ,"Seed" ))
sample_site$State<- factor(sample_site$State, levels = c('Healthy','Diseased'))

cbbPalette <- c("#203378","#6989b9","#a9c1a3","#e3bf2b")

p1<- ggplot(sample_site, aes(PCoA1, PCoA2, group = Compartment)) +
  geom_point(aes(color = Compartment,shape =State), size = 3, alpha = 1)+
  scale_color_manual(values = cbbPalette) +
  geom_vline(aes(xintercept = 0),linetype="dotted")+
  geom_hline(aes(yintercept = 0),linetype="dotted")+
  theme(panel.background = element_rect(fill='white', colour='black'),
        panel.grid=element_blank())+
  labs(x = paste('PCoA 1: ', round(100 * pcoa_eig[1], 2), '%'), y = paste('PCoA 2: ', round(100 * pcoa_eig[2], 2), '%'))+
  theme_bw()+
  theme(axis.ticks.length = unit(0.4,"lines"), axis.ticks = element_line(color='black'),
        axis.line = element_line(colour = "black"), 
        axis.title.x=element_text(colour='black', size=18,vjust = 1.5),
        axis.title.y=element_text(colour='black', size=18,vjust = 1.5),
        axis.text.y=element_text(colour='black',size=15),
        axis.text.x=element_text(colour = "black",size = 15,
                                 hjust = 1,vjust = 0.5))+
  stat_ellipse(aes(color = Compartment), level = 0.95, linetype = 6, show.legend = FALSE)+
  annotate("text",-0.30,0.52,label = "Site:R2=0.1307***
     Compartment:R2=0.0847***  
     Site:R2=0.0011*",size=5)
p1
ggsave("FungiPCoa.pdf",p1,width = 7,height = 7)


##############################################divide test
otu <- read.csv("t_wr.csv",sep = ",")
names(otu)[1]<-c("SampleID")
group<-read.delim("Group.csv")
aa<-merge(otu,group,by="SampleID")
library(dplyr)
aa <- aa %>% 
  filter(State != "Soil")
data_list <- split(aa, aa$Compartment)
df_split <- data_list
for (i in seq_along(df_split)) {
  filename <- paste0(names(df_split)[i], ".csv") 
  write.csv(df_split[[i]], file = filename, row.names = F) 
}


file_names <- list.files(pattern = "*.csv")
transpose_csv <- function(file_name) {
  data <- read.csv(file_name)
  transposed_data <- t(data)
  transposed_data<-transposed_data[-40307:-40312,]
  colnames(transposed_data)<-transposed_data[1,]
  transposed_data<-transposed_data[-1,]
  write.csv(transposed_data, file_name, row.names = T)
}
lapply(file_names, transpose_csv)

for (file_name in file_names) {
  data <- t(read.csv(file_name, header = T))
  colnames(data) <- data[1,]
  data <- data[-1,] 
  data <- cbind(SampleID = rownames(data), data)
  rownames(data) <- NULL
  group<-read.delim("Group.txt")
  group<-merge(group,data,by="SampleID")
  group<-group[1:4]
  data <- t(read.csv(file_name, header = T,row.names = 1))
  dist_mat <- vegdist(data,method = 'bray')
  result <-adonis2(dist_mat ~Site+State,group, permutations = 99)
  cat(paste("File name: ", file_name, "\n"))
  print(result)
  data.frame()
  write.csv(data.frame(result$R2,result$`Pr(>F)`) ,paste0(file_name, ".", file_name, "_adonis_result.csv"))
}

#######################Fig1F Fungi
aa<-
p<-ggplot(aa, aes(x = Compartment, y = R2, fill = group))+
  geom_bar(stat = "identity", width = 0.7)+
  geom_flow(aes(alluvium = group), alpha = 0.5) + 
  scale_fill_manual(values = c("#FF5900","#187c65"))+
  theme_bw()+ 
  xlab("Compartment")+
  ylab("PERMANOVA R2")+ 
  theme_bw()+
  theme(axis.ticks.length = unit(0.4,"lines"), axis.ticks = element_line(color='black'),
        axis.line = element_line(colour = "black"), 
        axis.title.x=element_text(colour='black', size=18,vjust = 1.5),
        axis.title.y=element_text(colour='black', size=18,vjust = 1.5),
        axis.text.y=element_text(colour='black',size=15),
        axis.text.x=element_text(colour = "black",size = 15,
                                 hjust = 1,vjust = 1,angle = (0))) 


