

library(ggplot2)
library(reshape2)
library(vegan)
pacman::p_load(tidyverse,rio,reshape2,survminer,patchwork,agricolae,survival)

aa<-read.csv("IR.csv")

names(aa)[2]<-c("DI")



kruskal.test(DI~Group,data=aa)
######################SI
head(aa)

oneway <- aov(DI ~ Group,data = aa)

lab <- LSD.test(oneway,"Group",p.adj="bonferroni", alpha = 0.05)$groups %>% 
  select(-DI) %>% 
  rownames_to_column('Group')


lab <- HSD.test(oneway,"Group",alpha = 0.05)$groups %>% 
  select(-DI) %>%  
  rownames_to_column('Group')
head(lab)
library(dplyr)


d1 <- aa %>%
  group_by(Group) %>%
  summarise(across(everything(), list(min = min, max = max))) %>%
 
  mutate(pos = DI_max + (max(DI_min) - min(DI_min)) * 0.2) %>%
  left_join(lab, by = "Group") %>%  
  select(Group, pos, groups)





d2 <-   
  aa %>%   
  left_join(d1) %>%   
  arrange(aa$groups) %>% 
  mutate(Group = factor(Group, levels = unique(Group), ordered = TRUE)) %>%   
  select(Group, everything())   
head(d2)
library(viridis)
custom_colors <- c("grey70","#b3ba9e","#93ba9e","#65ba9e" ) 
p1<-ggplot(d2, aes(x=Group, y=DI, fill=Group)) +
  geom_boxplot(outlier.size=1,size=1) +
  scale_fill_manual(values = custom_colors) +
  xlab('Group') +
  ylab('R') +
  theme_classic() +
  geom_text(aes(y=pos, label= groups),size = 5) +
  annotate("text",3,1.5,label = "Kruskal-Wallis: P = 0.0161",size=5)+
  geom_jitter( position=position_jitter(1), size=1)+ 
  theme(axis.text.x=element_text(angle=45,vjust=1, hjust=1),
        legend.position = 'none') +
  theme_bw(base_size = 16) +
  theme(axis.ticks.length = unit(0.4,"lines"), axis.ticks = element_line(color='black'),
        axis.line = element_line(colour = "black"), 
        axis.title.x=element_text(colour='black', size=20,vjust = 1.5),
        axis.title.y=element_text(colour='black', size=20,vjust = 1.5),#face = "bold"),
        axis.text.y=element_text(colour='black',size=18),#face = "bold"),
        axis.text.x=element_text(colour='black',size=18,angle = 60,hjust = 1),
        strip.text = element_text(colour = "black",size = 15,face = "bold"),
        legend.position = 'null')
p1
ggsave("R.pdf",p1,width = 5,height = 4)















