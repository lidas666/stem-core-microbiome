
library(ggtree)
library(ggplot2)
library(reshape2)
library(picante)
library(ape)
library(ggsci)
library(ggtreeExtra)
library(ggnewscale)
library(ggtree)
library(tidyverse)

##############################ba

b<-read.csv("Bacteria stem core.csv",row.names = 1)

w<-b
tw<-as.data.frame(t(w))
tw$SampleID<-row.names(tw)

gr<-read.csv("group.csv")

ww<-merge(gr,tw,by="SampleID")
library(dplyr)
df_summary <- ww %>%
  group_by(State) %>%
  summarise(across(everything(), mean, na.rm = TRUE))
df<-df_summary[-2:-8]

rownames(df)<-df$State
otus <- df[-1]
rownames(otus) <- rownames(df)
data<-as.data.frame(t(otus))

data$ID<-row.names(data)

#names(data)[3]<-c("tip.label") 

tree<-read.tree("ba_core.nwk")

data1<-read.csv("Bacteria core anno1.csv")
names(data1)[1]<-c("tip.label")
names(data)[3]<-c("tip.label")
da<-merge(data,data1,by="tip.label")
#tree$tip.label
df_Genus<-subset(da,select=c(tip.label,Genus))
list_Genus<-split(df_Genus$tip.label, df_Genus$Genus)
df_Genus$Genus<-as.factor(df_Genus$Genus)
tree_Genus<-groupOTU(tree,list_Genus)


da$Genus

p1 <- ggtree(tree_Genus, 
             branch.length = "none",
             layout = "fan",
             open.angle = 270,
             linetype=1,
             size=0.3,
             ladderize = F,
             aes(color=group))+
  scale_color_manual("group", values = c("Pantoea" ="#a31a1c",
                                         "Lactococcus"=  "#65472F",
                                         "Rahnella" = "#1f78b4",
                                         "Stenotrophomonas" = "#C5199E",
                                         "Klebsiella"= "#503378",
                                         "Escherichia" = "#FF5900",
                                         "Pseudomonas"  ="#e31a1c",
                                         "Enterobacter" = "#00B76D",
                                         "Un_Enterobacteriaceae" ="#B9A378", 
                                         "Un_Erwiniaceae" ="#C9E378" ))+
  geom_tiplab(size = 2, 
              align = TRUE, 
              linesize = 0.2) 
p1 


cols <- c("Pantoea" ="#a31a1c",
          "Lactococcus"=  "#65472F",
          "Rahnella" = "#1f78b4",
          "Stenotrophomonas" = "#C5199E",
          "Klebsiella"= "#503378",
          "Escherichia" = "#FF5900",
          "Pseudomonas"  ="#e31a1c",
          "Enterobacter" = "#00B76D" ,
          "Un_Enterobacteriaceae" ="#B9A378", 
          "Un_Erwiniaceae" ="#C9E378"
)


p2=p1+new_scale_fill() +
  geom_fruit(data=da,
             geom=geom_tile,
             mapping=aes(y=tip.label, fill=Genus),width = 0.5)+
  scale_fill_manual(values=cols)
p2



data2 <- data
rownames(data2) <- data2$tip.label
data2 <- data2[-3]
data3 <- as.data.frame(t(scale(t(data2))))

assign_values <- function(x) {
  max_val <- max(x)
  min_val <- min(x)
  mid_val <- x[!(x == max_val | x == min_val)]
  
  x[x == max_val] <- 3
  x[x == min_val] <- 1
  x[x == mid_val] <- 2
  
  x
}
data3 <- as.data.frame(t(apply(data3, 1, assign_values)))
colnames(data3) <- colnames(data2)

data3$ID<-rownames(data2)


df_new <- data3 %>%
  mutate(State = apply(data3, 1, function(row) {
    colnames(data3)[row == 3]
  }))

df_new$Pos <- ifelse(df_new$State == "Healthy", 1,
                     ifelse(df_new$State == "Diseased", 2, NA))


df_new1 <-df_new[-1:-2]

names(df_new1)[1]<-c("tr.tip.label")
names(data1)[1]<-c("tr.tip.label")
da1<-merge(data1,df_new1,by="tr.tip.label")


da1$State <- factor(da1$State, levels = c("Healthy", "Diseased"))
p3 <- p2 +  
  new_scale_fill() + 
  geom_fruit( data=da1,
              geom=geom_tile,
              mapping=aes(y=tr.tip.label,x=Pos,  fill=State),offset=0.28,  
              pwidth=0.1 ) +  
  scale_fill_manual(values=c("Healthy" = "#203378", "Diseased" = "#e3bf2b"),
                    guide=guide_legend(keywidth=0.5,keyheight=0.5, order=3)) 
p3


ggsave("Bacteria coreZOTU tree.pdf",p3,width =10,height = 8)


##############################fu

b<-read.csv("Fungi stem core.csv",row.names = 1)

w<-b
tw<-as.data.frame(t(w))
tw$SampleID<-row.names(tw)

gr<-read.csv("group.csv")

ww<-merge(gr,tw,by="SampleID")
library(dplyr)
df_summary <- ww %>%
  group_by(State) %>%
  summarise(across(everything(), mean, na.rm = TRUE))
df<-df_summary[-2:-8]

rownames(df)<-df$State
otus <- df[-1]
rownames(otus) <- rownames(df)
data<-as.data.frame(t(otus))

data$ID<-row.names(data)

#names(data)[3]<-c("tip.label") 

tree<-read.tree("fu_core.nwk")

data1<-read.csv("Fungi core anno.csv")
names(data1)[1]<-c("tip.label")
names(data)[3]<-c("tip.label")
da<-merge(data,data1,by="tip.label")
#tree$tip.label
df_Genus<-subset(da,select=c(tip.label,Genus))
list_Genus<-split(df_Genus$tip.label, df_Genus$Genus)
df_Genus$Genus<-as.factor(df_Genus$Genus)
tree_Genus<-groupOTU(tree,list_Genus)


da$Genus

p1 <- ggtree(tree_Genus, 
             branch.length = "none",
             layout = "fan",
             open.angle = 270,
             linetype=1,
             size=0.3,
             ladderize = F,
             aes(color=group))+
  scale_color_manual("group", values = c("Fusarium" ="#a31a1c",
                                         "Hannaella"=  "#65472F",
                                         "Cladosporium" = "#1f78b4",
                                         "Papiliotrema" = "#C5199E",
                                         "Alternaria"= "#503378",
                                         "Wickerhamomyces" = "#FF5900",
                                         "Meyerozyma"  ="#e31a1c",
                                         "Sarocladium" = "#10B76D",
                                         "Unassigned fungi" ="#B9A378", 
                                         "Mucor" ="#C9E378",
                                         "Candida" = "#11176F",
                                         "Trichoderma" ="#42A378", 
                                         "Penicillium" ="#227378",
                                         "Occultifur" ="#89A378", 
                                         "Unassigned Ophiostomatales" ="#555F27"
                                         ))+
  geom_tiplab(size = 2, 
              align = TRUE, 
              linesize = 0.2) 
p1 


cols <- c("Fusarium" ="#a31a1c",
          "Hannaella"=  "#65472F",
          "Cladosporium" = "#1f78b4",
          "Papiliotrema" = "#C5199E",
          "Alternaria"= "#503378",
          "Wickerhamomyces" = "#FF5900",
          "Meyerozyma"  ="#e31a1c",
          "Sarocladium" = "#10B76D",
          "Unassigned fungi" ="#B9A378", 
          "Mucor" ="#C9E378",
          "Candida" = "#11176F",
          "Trichoderma" ="#42A378", 
          "Penicillium" ="#227378",
          "Occultifur" ="#89A378", 
          "Unassigned Ophiostomatales" ="#555F27"
)


p2=p1+new_scale_fill() +
  geom_fruit(data=da,
             geom=geom_tile,
             mapping=aes(y=tip.label, fill=Genus),width = 0.5)+
  scale_fill_manual(values=cols)
p2



data2 <- data
rownames(data2) <- data2$tip.label
data2 <- data2[-3]
data3 <- as.data.frame(t(scale(t(data2))))

assign_values <- function(x) {
  max_val <- max(x)
  min_val <- min(x)
  mid_val <- x[!(x == max_val | x == min_val)]
  
  x[x == max_val] <- 3
  x[x == min_val] <- 1
  x[x == mid_val] <- 2
  
  x
}
data3 <- as.data.frame(t(apply(data3, 1, assign_values)))
colnames(data3) <- colnames(data2)

data3$ID<-rownames(data2)


df_new <- data3 %>%
  mutate(State = apply(data3, 1, function(row) {
    colnames(data3)[row == 3]
  }))

df_new$Pos <- ifelse(df_new$State == "Healthy", 1,
                     ifelse(df_new$State == "Diseased", 2, NA))


df_new1 <-df_new[-1:-2]

names(df_new1)[1]<-c("tr.tip.label")
names(data1)[1]<-c("tr.tip.label")
da1<-merge(data1,df_new1,by="tr.tip.label")


da1$State <- factor(da1$State, levels = c("Healthy", "Diseased"))
p3 <- p2 +  
  new_scale_fill() + 
  geom_fruit( data=da1,
              geom=geom_tile,
              mapping=aes(y=tr.tip.label,x=Pos,  fill=State),offset=0.28,  
              pwidth=0.1 ) +  
  scale_fill_manual(values=c("Healthy" = "#203378", "Diseased" = "#e3bf2b"),
                    guide=guide_legend(keywidth=0.5,keyheight=0.5, order=3)) 
p3


ggsave("Fungi coreZOTU tree.pdf",p3,width =10,height = 8)
