
library(ggplot2)
library(ggpubr)
library(reshape2)
library(vegan)
pacman::p_load(tidyverse, rio, reshape2, survminer, patchwork, agricolae, survival, ggsignif)

aa <- read.csv("da1.csv")
names(aa)[1] <- "Group"
aa<-aa[-2:-4]
aa<-aa[1:3]
head(aa)

aa<-melt(aa)
names(aa)[1:3] <-c( "Spe","Group","R")


shapiro <- shapiro.test(aa$R)
shapiro
var <- var.test(R ~ Group, data = aa)
var


p1 <- ggplot(data = aa, aes(x = Group, y = R, fill = Group)) +
  stat_summary(fun = mean, geom = "bar", position = position_dodge(width = 0.8), alpha = 0.7) +
  stat_summary(fun.data = mean_se, geom = "errorbar", position = position_dodge(width = 0.8), width = 0.2) +
  scale_fill_manual(limits = c("GCK", "G"), 
                    values = c("#eceb81", "#acea88")) +
  stat_compare_means(method = "t.test",paired = T, 
                     comparisons=list(c("GCK", "G")))+ 
  facet_wrap(~Spe, ncol=6)+
  theme_bw(base_size = 16) +
  theme(
    axis.ticks.length = unit(0.4, "lines"),
    axis.ticks = element_line(color = 'black'),
    axis.line = element_line(colour = "black"), 
    axis.title.x = element_text(colour = 'black', size = 20, vjust = 1.5),
    axis.title.y = element_text(colour = 'black', size = 20, vjust = 1.5),
    axis.text.y = element_text(colour = 'black', size = 18),
    axis.text.x = element_text(colour = 'black', size = 18, angle = 90, hjust = 1),
    strip.text = element_text(colour = "black", size = 15, face = "bold"),
    legend.position = 'right'
  ) +
  labs(y = 'Radius', x = 'Group')

p1
ggsave("IR_BarPlot.pdf", p1, width = 17, height = 5)
