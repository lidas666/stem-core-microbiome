

library(ggplot2)
library(ggpubr)

D1<-read.csv("fv_su.csv",row.names = 1)

library(reshape2)
head(D1)
d<-melt(D1)
write.csv(d,"fv_s.csv")


D1<-read.csv("fv_s.csv")



head(D1)
D1$Group <- factor(D1$Group, levels = c("FvWT","FvM"))  

p1 <- ggplot(data = D1, aes(x = Group, y = value, fill = Group)) +
  stat_summary(fun = mean, geom = "bar", position = position_dodge(width = 0.8), alpha = 0.7) +
  stat_summary(fun.data = mean_se, geom = "errorbar", position = position_dodge(width = 0.8), width = 0.2) +
  scale_fill_manual(limits = c("FvWT","FvM"), 
                    values = c("#eceb81", "#acea88")) +
  stat_compare_means(method = "t.test",paired = T, 
                     comparisons=list(c("FvWT","FvM")))+ 
  facet_wrap(~compound_name, ncol=7)+
  theme_bw(base_size = 16) +
  theme(
    axis.ticks.length = unit(0.4, "lines"),
    axis.ticks = element_line(color = 'black'),
    axis.line = element_line(colour = "black"), 
    axis.title.x = element_text(colour = 'black', size = 20, vjust = 1.5),
    axis.title.y = element_text(colour = 'black', size = 20, vjust = 1.5),
    axis.text.y = element_text(colour = 'black', size = 18),
    axis.text.x = element_text(colour = 'black', size = 18, angle = 90, hjust = 1),
    strip.text = element_text(colour = "black", size = 15, face = "bold"),
    legend.position = 'right'
  ) +
  labs(y = 'Value', x = 'Group')

p1
ggsave("Fgfu_bar.pdf",p1,width = 14,height = 9)



p1<-ggplot(data=D1, aes(x = Group, y =value,
                        color=Group)) +
  geom_boxplot(alpha =0.2,size=1,outlier.shape = NA)+
  stat_compare_means(method = "t.test",paired = F, 
                     comparisons=list(c("FvWT","FvM")))+
  scale_color_manual(limits=c("FvWT","FvM"), 
                     values=c("#bcea88","#fcec93"))+
  facet_wrap(~compound_name, ncol=7)+
  geom_jitter(size=2)+
  theme_bw(base_size = 16) +
  theme(axis.ticks.length = unit(0.4,"lines"), axis.ticks = element_line(color='black'),
        axis.line = element_line(colour = "black"), 
        axis.title.x=element_text(colour='black', size=20,vjust = 1.5),
        axis.title.y=element_text(colour='black', size=20,vjust = 1.5),#face = "bold"),
        axis.text.y=element_text(colour='black',size=18),#face = "bold"),
        axis.text.x=element_text(colour='black',size=18,angle = 0,hjust = 0.5),
        strip.text = element_text(colour = "black",size = 15,face = "bold"),
        legend.position = 'right')+
  labs(y='Value')
p1
ggsave("Fvfu_box.pdf",p1,width = 18,height = 9)
