
library(ggtree)
library(ggplot2)
library(reshape2)
library(picante)
library(ape)
library(ggsci)
library(ggtreeExtra)
library(ggnewscale)
library(ggtree)
library(tidyverse)
tree<-read.tree("fu.nwk")

data<- read.csv("fu1.csv", fileEncoding = "GBK")
data <- read.table("fu1.csv", header = TRUE, sep = ",", fileEncoding = "GBK",encoding = "UTF-8")
names(data)[1]<-c("tip.label")


da<-data
unique(da$phylum)
df_phylum<-subset(da,select=c(tip.label,phylum))
list_phylum<-split(df_phylum$tip.label, df_phylum$phylum)
df_phylum$phylum<-as.factor(df_phylum$phylum)
tree_phylum<-groupOTU(tree,list_phylum)



p1 <- ggtree(tree_phylum, 
             branch.length = "none",
             layout = "fan",
             open.angle = 270,
             linetype=1,
             size=0.5,
             aes(color=group))+
  scale_color_manual("group", values = c("Ascomycota" ="#FF5900",
                                         "Mortierellomycota"= "#203378",
                                         "Mucoromycota"  ="#00B76D"
                                         ))
p1 
ggsave("p1.pdf",p1,width = 14,height = 12)


a<-unique(da$Genus)
a



cols <- c("Fusarium" ="#e3bf2b",
          "Penicillium" =  "#e31a1c",
          "Aspergillus"  = "#1f78b4",
          "Talaromyces"  ="#00B76D",
          "Sporothrix" =  "#34472F",
          "Mucor"  = "#FF5900",
          "Cladosporium"  ="#203378",
          "Alternaria"  =  "#A4C9CC",
          "Trichoderma"  = "#65472F",
          "Meyerozyma" ="grey30",
          "Sarocladium" =  "#C5199E",
          "Epicoccum"  = "#cf78b4",
          "Arthrinium" ="#a3bf2b",
          "Mortierella"  =  "#b31a1c",
          "Chaetomium" = "#ff68a4",
          "Pleosporales" ="#c3bf2b",
          "Plectosphaerella" =  "#acb8d0"
)


p2=p1+new_scale_fill() +
  geom_fruit(data=da,
             geom=geom_tile,
             mapping=aes(y=tip.label, fill=Genus),width = 8,offset=0.08)+
  scale_fill_manual(values=cols)

p2

p3=p2+geom_fruit(
  data=da,
  geom = geom_col,
  mapping = aes(y=tip.label,x=IR,fill=Genus),
  pwidth = 0.3,offset=0.1,
  axis.params=list(axis="x",text.size =2),
  grid.params = list()
)+
  geom_tiplab(
    offset = 0.05,         
    align = TRUE,         
    linetype = NA,         
    size = 0.7,             
    color = "black",       
    hjust = -0.1          
  ) 
p3

ggsave("fu.pdf",p3,width = 14,height = 12)

