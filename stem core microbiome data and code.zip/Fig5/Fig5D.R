
library(dplyr)
library(ggplot2)
library(ggpubr)
D1<-read.csv("DI.csv")
shapiro.test(D1$DIncidence)
head(D1)

p1<-ggplot(data=D1, aes(x = Group, y =DIncidence,
                        color=Group)) +
  geom_boxplot(alpha =0.2,size=1,outlier.shape = NA)+
  stat_compare_means(method = "t.test",paired = F, 
                     comparisons=list(c("WT","M5")))+
  scale_color_manual(limits=c("WT","M5"), 
                     values=c("grey70","#f3ba9e"))+
  geom_jitter(size=2)+
  theme_bw(base_size = 16) +
  theme(axis.ticks.length = unit(0.4,"lines"), axis.ticks = element_line(color='black'),
        axis.line = element_line(colour = "black"), 
        axis.title.x=element_text(colour='black', size=20,vjust = 1.5),
        axis.title.y=element_text(colour='black', size=20,vjust = 1.5),#face = "bold"),
        axis.text.y=element_text(colour='black',size=18),#face = "bold"),
        axis.text.x=element_text(colour='black',size=18,angle = 0,hjust = 0.5),
        strip.text = element_text(colour = "black",size = 15,face = "bold"),
        legend.position = 'right')+
  labs(y='Disease incidence')
p1
ggsave("Disease incidence.pdf",p1,width = 4,height = 4)


shapiro.test(D1$DIndex)
D1$Group <- factor(D1$Group, levels = c("WT","M5"))  
p2<-ggplot(data=D1, aes(x = Group, y = DIndex,
                        color=Group)) +
  geom_boxplot(alpha =0.2,size=1,outlier.shape = NA)+
  scale_color_manual(limits=c("WT","M5"), 
                     values=c("#bcea88","#fcec93"))+
  stat_compare_means(method = "t.test",paired = F, 
                     comparisons=list(c("WT","M5")))+
  geom_jitter(size=3)+
  theme_bw(base_size = 16) +
  theme(axis.ticks.length = unit(0.4,"lines"), axis.ticks = element_line(color='black'),
        axis.line = element_line(colour = "black"), 
        axis.title.x=element_text(colour='black', size=20,vjust = 1.5),
        axis.title.y=element_text(colour='black', size=20,vjust = 1.5),#face = "bold"),
        axis.text.y=element_text(colour='black',size=18),#face = "bold"),
        axis.text.x=element_text(colour='black',size=18,angle = 0,hjust = 0.5),
        strip.text = element_text(colour = "black",size = 15,face = "bold"),
        legend.position = 'right')+
  labs(y='Disease index')
p2
ggsave("Disease index.pdf",p2,width = 4,height = 4)



