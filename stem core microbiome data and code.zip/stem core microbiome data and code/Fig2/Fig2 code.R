
library(reshape2)
library(vegan)
library(ggplot2)
library(RColorBrewer)
library(ggalluvial)
library(imputeTS)
library(rfPermute)
#################################################################bacteria  Fig2A
tax<- read.table("Bacteria taxa.csv",header=T,sep=",")
otu <-read.csv("Bacteria relative abundance.csv",row.names = 1)
tax$phylum<-factor(tax$Phylum)
tax$class<-factor(tax$Class)
tax$order<-factor(tax$Order)
tax$family<-factor(tax$Family)
tax$genus<-factor(tax$Genus)
c<- aggregate(otu, by=list(tax$class), sum) 
o<- aggregate(otu, by=list(tax$order), sum) 
f<- aggregate(otu, by=list(tax$family), sum) 
g<-aggregate(otu, by=list(tax$genus), sum) 

write.csv(p,"Bacteria phylum.csv",row.names = F)
write.csv(c,"Bacteria class.csv",row.names = F)
write.csv(o,"Bacteria order.csv",row.names = F)
write.csv(f,"Bacteria family.csv",row.names = F)
write.csv(g,"Bacteria genus.csv",row.names = F)

taxon=tax
c<-read.csv("Bacteria phylum.csv",row.names = 1)

top_10<- names(head(sort(rowSums(c), decreasing = T), 10)) 
top_10
top_10<-c("Proteobacteria"  , "Actinobacteriota" ,"Firmicutes"    ,   "Bacteroidota"    
          , "Chloroflexi"  ,    "Patescibacteria" , "Acidobacteriota" , "Gemmatimonadota" 
          , "Myxococcota"  ,    "Unclassified" ) 
taxon$Phylum[!(taxon$Phylum)%in%top_10]<-"Others" 
c_top<- aggregate(otu, by=list(taxon$Phylum), sum)
rownames(c_top)<-c_top[,1]
c_top=c_top[,-1]
c_top=c_top[order(-rowSums(c_top)),]
c_top1<-c_top
c_top2<-t(c_top1)
c_top2 <- cbind(rownames(c_top2), c_top2)
rownames(c_top2) <- NULL
colnames(c_top2)[1]<-c("SampleID")
group<-read.csv("Group.csv")
c_top4<-merge(group,c_top2,by="SampleID")
c_top5<-melt(c_top4,id=1:6)
colnames(c_top5)[7:8]<-c("Phylum","Abundance")
g<-melt(g)
write.csv(c_top4,"p_top10.csv",row.names = F)
data<-c_top5
library(dplyr)
data <- data %>% 
  filter(State != "Soil")
data$Abundance<-as.numeric(data$Abundance)

da1<-data%>% 
  select(Compartment,State,Phylum,Abundance) %>%
  group_by(Compartment,State,Phylum) %>% 
  summarise_all(mean)
dim(da1)
head(da1)

library(ggalluvial)
library(imputeTS)

cols <- c("#203378","#e3bf2b","#e31a1c","#1f78b4","#00B76D","#FF5900","#C5199E", "#C2855E",
          "#A4C9CC","#65472F", "#DD7694")

ggplot(data = da1,
       aes(x = State, y = Abundance, fill = reorder(Phylum,-Abundance), 
           stratum = reorder(Phylum,-Abundance),
           alluvium = reorder(Phylum,-Abundance))) +
  geom_alluvium()+
  geom_stratum(width=0.45, size=0.1) +
  geom_bar(aes(fill = reorder(Phylum,-Abundance)),stat='identity', width=0.7) +
  scale_y_continuous(expand=c(0, 0))+
  theme_bw() +
  facet_grid( ~ Compartment,scales = "fixed")+
  scale_fill_manual(values = cols,name="Phylum") +
  scale_color_manual(values = cols) +
  theme(legend.position = "right",
        panel.grid=element_blank(),
        panel.spacing.x = unit(0,units = "cm"),
        strip.background = element_rect(
          color="white", fill="white", 
          linetype="solid",size=0.8),
        strip.placement = "outside",
        axis.line.y.left = element_line(color="black",size=0.8),
        axis.line.x.bottom = element_line(color="black",size=0.8),
        strip.text.x = element_text(size = 14,face = "bold"),
        axis.text = element_text(face = "bold", 
                                 size = 12,color="black"),
        axis.title = element_text(face = "bold", 
                                  size = 14,colour = "black"),
        legend.title = element_text(face = "bold", 
                                    size =12,color="black"),
        legend.text = element_text(face = "bold", size =12,color="black"),
        axis.ticks.x = element_blank(),
        axis.ticks.y = element_line(size = 0.3),
  )+
  theme(axis.ticks.length = unit(0.4,"lines"), axis.ticks = element_line(color='black'),
        axis.line = element_line(colour = "black"), 
        axis.title.x=element_text(colour='black', size=18,vjust = 1.5),
        axis.title.y=element_text(colour='black', size=18,vjust = 1.5),
        axis.text.y=element_text(colour='black',size=15),
        axis.text.x=element_text(colour = "black",size = 15,
                                 hjust = 1,vjust = 1,angle = 45))+
  labs(x = "State",y= "Relative Abundance of Phylum (%)")


#################################################################Fungi Fig2B
tax<- read.table("Fungi taxa.csv",header=T,sep=",")
otu <-read.csv("Fungi relative abundance.csv",row.names = 1)
tax$phylum<-factor(tax$Phylum)
tax$class<-factor(tax$Class)
tax$order<-factor(tax$Order)
tax$family<-factor(tax$Family)
tax$genus<-factor(tax$Genus)
c<- aggregate(otu, by=list(tax$class), sum) 
o<- aggregate(otu, by=list(tax$order), sum) 
f<- aggregate(otu, by=list(tax$family), sum) 
g<-aggregate(otu, by=list(tax$genus), sum) 

write.csv(p,"Fungi phylum.csv",row.names = F)
write.csv(c,"Fungi class.csv",row.names = F)
write.csv(o,"Fungi order.csv",row.names = F)
write.csv(f,"Fungi family.csv",row.names = F)
write.csv(g,"Fungi genus.csv",row.names = F)

taxon=tax
c<-read.csv("Fungi phylum.csv",row.names = 1)

top_10<- names(head(sort(rowSums(c), decreasing = T), 10)) 
top_10
top_10<-c("Ascomycota" ,      "Unassigned" ,    "Basidiomycota" ,    "Mucoromycota"     
          , "Glomeromycota"  ,   "Rozellomycota"  ,   "Chytridiomycota"  , "unidentified"     
          , "Zoopagomycota" ,   "Mortierellomycota") 
taxon$Phylum[!(taxon$Phylum)%in%top_10]<-"Others" 
c_top<- aggregate(otu, by=list(taxon$Phylum), sum)
rownames(c_top)<-c_top[,1]
c_top=c_top[,-1]
c_top=c_top[order(-rowSums(c_top)),]
c_top1<-c_top
c_top2<-t(c_top1)
c_top2 <- cbind(rownames(c_top2), c_top2)
rownames(c_top2) <- NULL
colnames(c_top2)[1]<-c("SampleID")
group<-read.csv("Group.csv")
c_top4<-merge(group,c_top2,by="SampleID")
c_top5<-melt(c_top4,id=1:6)
colnames(c_top5)[7:8]<-c("Phylum","Abundance")
g<-melt(g)
write.csv(c_top4,"p_top10.csv",row.names = F)
data<-c_top5
library(dplyr)
data <- data %>% 
  filter(State != "Soil")
data$Abundance<-as.numeric(data$Abundance)

da1<-data%>% 
  select(Compartment,State,Phylum,Abundance) %>%
  group_by(Compartment,State,Phylum) %>% 
  summarise_all(mean)
dim(da1)
head(da1)

library(ggalluvial)
library(imputeTS)

cols <- c("#203378","#e3bf2b","#e31a1c","#1f78b4","#00B76D","#FF5900","#C5199E", "#C2855E",
          "#A4C9CC","#65472F", "#DD7694")

ggplot(data = da1,
       aes(x = State, y = Abundance, fill = reorder(Phylum,-Abundance), 
           stratum = reorder(Phylum,-Abundance),
           alluvium = reorder(Phylum,-Abundance))) +
  geom_alluvium()+
  geom_stratum(width=0.45, size=0.1) +
  geom_bar(aes(fill = reorder(Phylum,-Abundance)),stat='identity', width=0.7) +
  scale_y_continuous(expand=c(0, 0))+
  theme_bw() +
  facet_grid( ~ Compartment,scales = "fixed")+
  scale_fill_manual(values = cols,name="Phylum") +
  scale_color_manual(values = cols) +
  theme(legend.position = "right",
        panel.grid=element_blank(),
        panel.spacing.x = unit(0,units = "cm"),
        strip.background = element_rect(
          color="white", fill="white", 
          linetype="solid",size=0.8),
        strip.placement = "outside",
        axis.line.y.left = element_line(color="black",size=0.8),
        axis.line.x.bottom = element_line(color="black",size=0.8),
        strip.text.x = element_text(size = 14,face = "bold"),
        axis.text = element_text(face = "bold", 
                                 size = 12,color="black"),
        axis.title = element_text(face = "bold", 
                                  size = 14,colour = "black"),
        legend.title = element_text(face = "bold", 
                                    size =12,color="black"),
        legend.text = element_text(face = "bold", size =12,color="black"),
        axis.ticks.x = element_blank(),
        axis.ticks.y = element_line(size = 0.3),
  )+
  theme(axis.ticks.length = unit(0.4,"lines"), axis.ticks = element_line(color='black'),
        axis.line = element_line(colour = "black"), 
        axis.title.x=element_text(colour='black', size=18,vjust = 1.5),
        axis.title.y=element_text(colour='black', size=18,vjust = 1.5),
        axis.text.y=element_text(colour='black',size=15),
        axis.text.x=element_text(colour = "black",size = 15,
                                 hjust = 1,vjust = 1,angle = 45))+
  labs(x = "State",y= "Relative Abundance of Phylum (%)")



rm(list = ls())
setwd("F:/博士/博士/文章撰写/茎部核心微生物组抗病/原始数据与绘图代码/Fig2")
getwd()
library(edgeR)
library(limma)
##########Bacteria Stem
counts <- read.csv("Bacteria stem abundance.csv")
colnames(counts)[1] <- "ID"
metadata <- read.csv("Group_Stem.csv")
counts = data.frame(counts)
row_name = counts$ID
row.names(counts) <- row_name
counts = counts[,-1]
counts <- counts[which(rowSums(counts) > 20), ]
dgelist <- DGEList(counts = counts, group = metadata$State)
keep <- rowSums(cpm(dgelist) > 1 ) >= 2
dgelist <- dgelist[keep, ,keep.lib.sizes = FALSE]
dgelist_norm <- calcNormFactors(dgelist, method = 'TMM')
design <- model.matrix(~metadata$State)
dge <- estimateDisp(dgelist_norm, design, robust = TRUE)
fit <- glmFit(dge, design, robust = TRUE) 
lrt <- glmLRT(fit) 
aa<-lrt$table
aa$AdjustedPValue <- p.adjust(aa$PValue, method = "fdr")
aa <- cbind(ID = rownames(aa), aa)
rownames(aa) <- NULL
colnames(aa)[1] <- "ID"
aa$Compartment <- c("Stem")
tax<-read.csv("Bacteria taxa.csv")
colnames(tax)[1] <- "ID"
aa3<-merge(aa,tax,by="ID")


BRCA_Match_DEG<-aa3
library(dplyr)
colnames(BRCA_Match_DEG)[1] <- "ID"
BRCA_Match_DEG$log10AdjustedPValue <- -log10(BRCA_Match_DEG$AdjustedPValue)
BRCA_Match_DEG <- BRCA_Match_DEG %>% 
  mutate(DEG = case_when(logFC > 2 & AdjustedPValue < 0.05 ~ "up",
                         abs(logFC) < 2 | AdjustedPValue > 0.05 ~ "no",
                         logFC < -2 & AdjustedPValue < 0.05 ~ "down"))

write.csv(BRCA_Match_DEG,"Bacteria edg.csv")


library(ggplot2)
library(ggprism)
library(ggrepel)
p1<-ggplot(BRCA_Match_DEG, aes(x =logFC, y=log10AdjustedPValue, colour=DEG)) +
  geom_point(alpha=0.85, size=1.2) +
  scale_color_manual(values=c("#e3bf2b",'gray',"#203378")) +
  xlim(c(-11, 11)) +  
  geom_vline(xintercept=c(-2,2),lty=4,col="black",lwd=0.8)+
  geom_hline(yintercept = -log10(0.05), lty=4,col="black",lwd=0.8) + 
  labs(x="logFC", y="-log10(Adj P Value)") +
  ggtitle("Different ZOTUs") + 
  theme_bw()+
  theme(axis.ticks.length = unit(0.4,"lines"), axis.ticks = element_line(color='black'),
        axis.line = element_line(colour = "black"), 
        axis.title.x=element_text( size=18,vjust = 1.5),
        axis.title.y=element_text( size=18,vjust = 1.5),
        axis.text.y=element_text(size=15),
        axis.text.x=element_text(size = 15,
                                 hjust = 1,vjust = 0.5))
p1
ggsave("Bacteria edg.pdf",p1,width =4.6,height = 4)



##########Fungi Stem
counts <- read.csv("Fungi stem abundance.csv")
colnames(counts)[1] <- "ID"
metadata <- read.csv("Group_Stem.csv")
counts = data.frame(counts)
row_name = counts$ID
row.names(counts) <- row_name
counts = counts[,-1]
counts <- counts[which(rowSums(counts) > 20), ]
dgelist <- DGEList(counts = counts, group = metadata$State)
keep <- rowSums(cpm(dgelist) > 1 ) >= 2
dgelist <- dgelist[keep, ,keep.lib.sizes = FALSE]
dgelist_norm <- calcNormFactors(dgelist, method = 'TMM')
design <- model.matrix(~metadata$State)
dge <- estimateDisp(dgelist_norm, design, robust = TRUE)
fit <- glmFit(dge, design, robust = TRUE) 
lrt <- glmLRT(fit) 
aa<-lrt$table
aa$AdjustedPValue <- p.adjust(aa$PValue, method = "fdr")
aa <- cbind(ID = rownames(aa), aa)
rownames(aa) <- NULL
colnames(aa)[1] <- "ID"
aa$Compartment <- c("Stem")
tax<-read.csv("Fungi taxa.csv")
colnames(tax)[1] <- "ID"
aa3<-merge(aa,tax,by="ID")


BRCA_Match_DEG<-aa3
library(dplyr)
colnames(BRCA_Match_DEG)[1] <- "ID"
BRCA_Match_DEG$log10AdjustedPValue <- -log10(BRCA_Match_DEG$AdjustedPValue)
BRCA_Match_DEG <- BRCA_Match_DEG %>% 
  mutate(DEG = case_when(logFC > 2 & AdjustedPValue < 0.05 ~ "up",
                         abs(logFC) < 2 | AdjustedPValue > 0.05 ~ "no",
                         logFC < -2 & AdjustedPValue < 0.05 ~ "down"))

write.csv(BRCA_Match_DEG,"Fungi edg.csv")


library(ggplot2)
library(ggprism)
library(ggrepel)
p1<-ggplot(BRCA_Match_DEG, aes(x =logFC, y=log10AdjustedPValue, colour=DEG)) +
  geom_point(alpha=0.85, size=1.2) +
  scale_color_manual(values=c("#e3bf2b",'gray',"#203378")) +
  xlim(c(-11, 11)) +  ##调整x轴的取值范围，可以根据max(abs(BRCA_Match_DEG$logFC))，获得差异基因最大值是多少，再进行取舍
  geom_vline(xintercept=c(-2,2),lty=4,col="black",lwd=0.8)+
  geom_hline(yintercept = -log10(0.05), lty=4,col="black",lwd=0.8) + 
  labs(x="logFC", y="-log10(Adj P Value)") +
  ggtitle("Different ZOTUs") + 
  theme_bw()+
  theme(axis.ticks.length = unit(0.4,"lines"), axis.ticks = element_line(color='black'),
        axis.line = element_line(colour = "black"), 
        axis.title.x=element_text( size=18,vjust = 1.5),
        axis.title.y=element_text( size=18,vjust = 1.5),
        axis.text.y=element_text(size=15),
        axis.text.x=element_text(size = 15,
                                 hjust = 1,vjust = 0.5))
p1
ggsave("Fungi edg.pdf",p1,width =4.6,height = 4)




st<-read.csv("Bacteria stem abundance.csv",row.names = 1)
w<-st
w1<-read.csv("Bacteria stem abundance.csv",)
names(w1)[1]<-c("OTUID")
otu_table<-w1
library(dplyr)
otu_table <- otu_table %>%
  rowwise() %>%
  mutate(mean_abundance = mean(c_across(-OTUID)))
sorted_otu_table <- otu_table %>%
  arrange(desc(mean_abundance))
top_1_percent_otu <- sorted_otu_table[1:round(nrow(sorted_otu_table) * 0.01), ]
w2<-top_1_percent_otu

rownames(w2)<-w2$OTUID
top_otus <- w2[, -1, drop = FALSE]
print(rownames(top_otus))
genus<-top_otus
genus1 <- genus
genus1[genus1>0] <- 1
genus <- genus[which(rowSums(genus1) > 225), ] 
stc<-genus
write.csv(stc,"Bacteria_stem_core_0.01_0.75.csv",row.names = F)

genus2<-genus1
genus2<- genus1[which(rowSums(genus1) > 225), ] 
genus3<-as.data.frame(t(genus2))
genus3$SampleID<-row.names(genus3)  
gr<-read.csv("group_stem.csv")
ww<-merge(gr,genus3,by="SampleID")
head(ww)
data<-ww
library(dplyr)
library(tidyr)
data_long <- data %>%
  select(Site, starts_with("OTU")) %>%
  pivot_longer(cols = starts_with("OTU"), names_to = "OTU", values_to = "count")
result <- data_long %>%
  group_by(Site,  OTU) %>%
  summarise(sample_count = sum(count), .groups = "drop")
data_matrix <- xtabs(sample_count ~ Site + OTU, data = result)

library(pheatmap)
my_colors <- colorRampPalette(c("#c1bf2b",'gray',"#653378"))(100)
p1<-pheatmap(data_matrix, 
         scale = "none", 
         main = "Heatmap of Count by Site and OTU",
         xlab = "OTU", 
         ylab = "Site",
         color = my_colors, 
         display_numbers = TRUE,  
         number_format = "%.0f", 
         number_color = "black" 
)

ggsave("Bacteria coreZOTU distribution.pdf",p1,width =10,height = 8)




rm(list = ls())
setwd("F:/博士/博士/文章撰写/茎部核心微生物组抗病/原始数据与绘图代码/Fig2")
getwd()

st<-read.csv("Fungi stem abundance.csv",row.names = 1)
w<-st
w1<-read.csv("Fungi stem abundance.csv",)
names(w1)[1]<-c("OTUID")
otu_table<-w1
library(dplyr)
otu_table <- otu_table %>%
  rowwise() %>%
  mutate(mean_abundance = mean(c_across(-OTUID)))
sorted_otu_table <- otu_table %>%
  arrange(desc(mean_abundance))
top_1_percent_otu <- sorted_otu_table[1:round(nrow(sorted_otu_table) * 0.01), ]
w2<-top_1_percent_otu

rownames(w2)<-w2$OTUID
top_otus <- w2[-1]
rownames(top_otus) <- rownames(w2)
print(rownames(top_otus))
genus<-top_otus
genus1 <- genus
genus1[genus1>0] <- 1
genus <- genus[which(rowSums(genus1) > 225), ] 
stc<-genus
write.csv(stc,"Fungi_stem_core_0.01_0.75.csv",row.names = F)

genus2<-genus1
genus2<- genus1[which(rowSums(genus1) > 225), ] 
genus3<-as.data.frame(t(genus2))
genus3$SampleID<-row.names(genus3)  
gr<-read.csv("group_stem.csv")
ww<-merge(gr,genus3,by="SampleID")
head(ww)
data<-ww
library(dplyr)
library(tidyr)
data_long <- data %>%
  select(Site, starts_with("OTU")) %>%
  pivot_longer(cols = starts_with("OTU"), names_to = "OTU", values_to = "count")
result <- data_long %>%
  group_by(Site,  OTU) %>%
  summarise(sample_count = sum(count), .groups = "drop")
data_matrix <- xtabs(sample_count ~ Site + OTU, data = result)

library(pheatmap)
my_colors <- colorRampPalette(c("#c1bf2b",'gray',"#653378"))(100)
p1<-pheatmap(data_matrix, 
             scale = "none", 
             main = "Heatmap of Count by Site and OTU",
             xlab = "OTU", 
             ylab = "Site",
             color = my_colors, 
             display_numbers = TRUE,  
             number_format = "%.0f", 
             number_color = "black" 
)

ggsave("Fungi coreZOTU distribution.pdf",p1,width =10,height = 8)
