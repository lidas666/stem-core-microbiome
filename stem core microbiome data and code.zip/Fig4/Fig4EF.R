
library(ggplot2)
###############################
gl<-read.csv("gl_au.csv")
df<-gl

p1<-ggplot(df, aes(x = Time, y = AU)) +
  geom_line(color = "black", linewidth = 0.5) +
  labs(
    title = "Gliotoxin",
    x = "Time (min)",
    y = "Absorbance Units (AU)"
  ) +
  theme_minimal() +
  scale_x_continuous(breaks = seq(0, max(df$Time), 2)) +  
  theme_bw(base_size = 16) +
  theme(axis.ticks.length = unit(0.4,"lines"), axis.ticks = element_line(color='black'),
        axis.line = element_line(colour = "black"), 
        axis.title.x=element_text(colour='black', size=20,vjust = 1.5),
        axis.title.y=element_text(colour='black', size=20,vjust = 1.5),
        axis.text.y=element_text(colour='black',size=18),
        axis.text.x=element_text(colour='black',size=18,angle = 0,hjust = 1),
        strip.text = element_text(colour = "black",size = 15,face = "bold"),
        legend.position = 'right')
p1


ggsave("Gliotoxin_au.pdf",p1,width = 6,height = 4)
#################################
gl<-read.csv("f4_au.csv")
df<-gl
max_au <- max(df$AU)                     
max_time <- df$Time[which.max(df$AU)]   
p1<-ggplot(df, aes(x = Time, y = AU)) +
  geom_line(color = "black", linewidth = 0.5) +
  labs(
    title = "T",
    x = "Time (min)",
    y = "Absorbance Units (AU)"
  ) +
  theme_minimal() +
  scale_x_continuous(breaks = seq(0, max(df$Time), 2)) +  
  theme_bw(base_size = 16) +
  theme(axis.ticks.length = unit(0.4,"lines"), axis.ticks = element_line(color='black'),
        axis.line = element_line(colour = "black"), 
        axis.title.x=element_text(colour='black', size=20,vjust = 1.5),
        axis.title.y=element_text(colour='black', size=20,vjust = 1.5),#face = "bold"),
        axis.text.y=element_text(colour='black',size=18),#face = "bold"),
        axis.text.x=element_text(colour='black',size=18,angle = 0,hjust = 1),
        strip.text = element_text(colour = "black",size = 15,face = "bold"),
        legend.position = 'right')
p1


ggsave("T_au.pdf",p1,width = 6,height = 4)




###############################
gl<-read.csv("gl_ms.csv")
df<-gl

p1<-ggplot(df, aes(x = mz, y = P/10000)) +
  geom_line(color = "black", linewidth = 0.5) +
  labs(
    title = "Gliotoxin",
    x = "m/z",
    y = "%"
  ) +
  theme_minimal() +
  scale_x_continuous(breaks = seq(0, max(df$mz), 50)) +  
  theme_bw(base_size = 16) +
  theme(axis.ticks.length = unit(0.4,"lines"), axis.ticks = element_line(color='black'),
        axis.line = element_line(colour = "black"), 
        axis.title.x=element_text(colour='black', size=20,vjust = 1.5),
        axis.title.y=element_text(colour='black', size=20,vjust = 1.5),#face = "bold"),
        axis.text.y=element_text(colour='black',size=18),#face = "bold"),
        axis.text.x=element_text(colour='black',size=18,angle = 30,hjust = 1),
        strip.text = element_text(colour = "black",size = 15,face = "bold"),
        legend.position = 'right')
p1


ggsave("Gliotoxin_mz.pdf",p1,width = 6,height = 4)
#################################
gl<-read.csv("f4_ms.csv")
df<-gl

p1<-ggplot(df, aes(x = mz, y = P/10000)) +
  geom_line(color = "black", linewidth = 0.5) +
  labs(
    title = "T",
    x = "m/z",
    y = "%"
  ) +
  theme_minimal() +
  scale_x_continuous(breaks = seq(0, max(df$mz), 50)) +  
  theme_bw(base_size = 16) +
  theme(axis.ticks.length = unit(0.4,"lines"), axis.ticks = element_line(color='black'),
        axis.line = element_line(colour = "black"), 
        axis.title.x=element_text(colour='black', size=20,vjust = 1.5),
        axis.title.y=element_text(colour='black', size=20,vjust = 1.5),#face = "bold"),
        axis.text.y=element_text(colour='black',size=18),#face = "bold"),
        axis.text.x=element_text(colour='black',size=18,angle = 30,hjust = 1),
        strip.text = element_text(colour = "black",size = 15,face = "bold"),
        legend.position = 'right')
p1


ggsave("T_mz.pdf",p1,width = 6,height = 4)
