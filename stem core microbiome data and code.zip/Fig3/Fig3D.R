
library(ggplot2)
library(reshape2)
library(vegan)
library(ape)
library(picante) 
library(edgeR)
azdif<-read.csv("azdif.csv")

head(azdif)
BRCA_Match_DEG<-azdif
library(dplyr)
colnames(BRCA_Match_DEG)[1] <- "ID"
BRCA_Match_DEG$log10PValue <- -log10(BRCA_Match_DEG$P)
BRCA_Match_DEG <- BRCA_Match_DEG %>% 
  mutate(DEG = case_when(LogFC>0 & VIP >1 & P < 0.05 ~ "up",
                          VIP < 1 | P > 0.05 ~ "no",
                         LogFC<0 & VIP > 1 & P < 0.05 ~ "down"))

write.csv(BRCA_Match_DEG,"差异结果vip1.csv")

library(ggplot2) 
library(ggprism) 
library(ggrepel)


p1 <- ggplot(BRCA_Match_DEG, aes(x = LogFC, y = log10PValue, colour = DEG, size = VIP)) +
  geom_point(alpha = 0.85,size=BRCA_Match_DEG$VIP * 0.5) +
  scale_size(range = c(1, 10)) +
  scale_color_manual(values = c("#c29f62", "gray", "#83ba9e")) +
  xlim(c(-8, 8)) +
  ylim(c(-0.5, 10)) +
  geom_vline(xintercept = c(-0.5, 0.5), lty = 4, col = "black", lwd = 0.8) +
  geom_hline(yintercept = -log10(0.05), lty = 4, col = "black", lwd = 0.8) +
  labs(x = "logFC", y = "-log10(PValue)") +
  ggtitle("Different metabolites") +
  theme_bw() +
  theme(
    axis.ticks.length = unit(0.4, "lines"),
    axis.ticks = element_line(color = "black"),
    axis.line = element_line(colour = "black"),
    axis.title.x = element_text(size = 18, vjust = 1.5),
    axis.title.y = element_text(size = 18, vjust = 1.5),
    axis.text.y = element_text(size = 15),
    axis.text.x = element_text(size = 15, hjust = 1, vjust = 0.5)
  ) +
  guides(colour = guide_legend(title = "DEG"), size = guide_legend(title = "VIP"))  
p1

ggsave("metabolites火山图VIP_1.pdf",p1,width =4.6,height = 4)

###########################


aa<-read.csv("差异结果注释后.csv")
tax<-aa[1:5]

otu<-aa[-2:-5]
otu<-otu[-8:-9]
rownames(otu)<-otu$ID
otu<-otu[-1]
head(tax)
tax$Super.Class<-factor(tax$Super.Class)
tax$Class<-factor(tax$Class)
tax$Sub.Class<-factor(tax$Sub.Class)


sup<- aggregate(otu, by=list(tax$Super.Class), sum)
cl<- aggregate(otu, by=list(tax$Class), sum) 
sub<- aggregate(otu, by=list(tax$Sub.Class), sum) 



write.csv(sup,"superclass.csv",row.names = F)
write.csv(cl,"class.csv",row.names = F)
write.csv(sub,"subclass.csv",row.names = F)
#################################################superclass
mat<-sup
rownames(mat)<-mat$Group.1
mat<-mat[-1]
mat <-t(mat)
mat <- as.matrix(mat)
mat1<-scale(mat)

library(ComplexHeatmap)

Heatmap(
  mat1, name = 'Metabolites',
  col = colorRampPalette(c('grey40', 'grey60', 'grey80',"#90C2B2","#28B888","#015438" ))(100),
  cluster_rows = T, cluster_columns = T
)


#################################################Class
mat<-cl
rownames(mat)<-mat$Group.1
mat<-mat[-1]
mat <-t(mat)
mat <- as.matrix(mat)
mat1<-scale(mat)

library(ComplexHeatmap)

Heatmap(
  mat1, name = 'Metabolites',
  col = colorRampPalette(c('grey40', 'grey60', 'grey80',"#90C2B2","#28B888","#015438" ))(100),
  cluster_rows = T, cluster_columns = T
)

#################################################SubClass
mat<-sub
rownames(mat)<-mat$Group.1
mat<-mat[-1]
mat <-t(mat)
mat <- as.matrix(mat)
mat1<-scale(mat)

library(ComplexHeatmap)

Heatmap(
  mat1, name = 'Metabolites',
  col = colorRampPalette(c('grey40', 'grey60', 'grey80',"#90C2B2","#28B888","#015438" ))(100),
  cluster_rows = T, cluster_columns = T
)


