

library(ggtree)
library(ggplot2)
library(reshape2)
library(picante)
library(ape)
library(ggsci)
library(ggtreeExtra)
library(ggnewscale)
library(ggtree)
library(tidyverse)
tree<-read.tree("ba.nwk")

data<- read.csv("ba1.csv", fileEncoding = "GBK")
data <- read.table("ba1.csv", header = TRUE, sep = ",", fileEncoding = "GBK",encoding = "UTF-8")
names(data)[1]<-c("tip.label")


da<-data
unique(da$phylum)
df_phylum<-subset(da,select=c(tip.label,phylum))
list_phylum<-split(df_phylum$tip.label, df_phylum$phylum)
df_phylum$phylum<-as.factor(df_phylum$phylum)
tree_phylum<-groupOTU(tree,list_phylum)



p1 <- ggtree(tree_phylum, 
             branch.length = "none",
             layout = "fan",
             open.angle = 270,
             linetype=1,
             size=0.5,
             aes(color=group))+
  scale_color_manual("group", values = c("Proteobacteria"  ="#FF5900",
                                         "Firmicutes"= "#203378",
                                         "Bacteroidota"  ="#00B76D",
                                         "Actinobacteriota"  ="#DD7694"
  ))
p1 


a<-unique(da$Genus)
a



cols <- c("Burkholderia"  ="#e3bf2b",
          "Priestia"  =  "#e31a1c",
          "Paenibacillus"   = "#1f78b4",
          "Stenotrophomonas"  ="#00B76D",
          "Staphylococcus"   =  "#34472F",
          "Bacillus"    = "#FF5900",
          "Pantoea"   ="#203378",
          "Peribacillus"  =  "#A4C9CC",
          "Leclercia"   = "#65472F",
          "Sphingomonas" ="grey30",
          "Raoultella" =  "#C5199E",
          "Pseudomonas"    = "#cf78b4",
          "Klebsiella" ="#a3bf2b",
          "Erwinia"   =  "#b31a1c",
          "Chryseobacterium" = "#ff68a4",
          "Acinetobacter" ="#c3bf2b",
          "Acidovorax" =  "#acb8d0",
          "Flavobacterium"  ="#bcea88",
          "Pedobacter"   ="#4e81b9",
          "Lactococcus"  ="#cbb2d0",
          "Rhizobium" ="#935827",
          "Agrobacterium"  ="#373d5c",
          "Curtobacterium" ="#baccf4",
          "Hymenobacter"  ="#e28da0",
          "Xanthomonas"  ="#e3bf2b",
          "Enterobacter" ="#a33233",
          "Sphingobium"  ="#666543"
          
          
          
          
          
)


p2=p1+new_scale_fill() +
  geom_fruit(data=da,
             geom=geom_tile,
             mapping=aes(y=tip.label, fill=Genus),width = 3.5,offset=0.08)+
  scale_fill_manual(values=cols)

p2

p3=p2+geom_fruit(
  data=da,
  geom = geom_col,
  mapping = aes(y=tip.label,x=IR,fill=Genus),
  pwidth = 0.3,offset=0.1,
  axis.params=list(axis="x",text.size =2),
  grid.params = list()
)+
  geom_tiplab(
    offset = 0.05,        
    align = TRUE,         
    linetype = NA,       
    size = 0.7,            
    color = "black",       
    hjust = -0.1         
  ) 
p3

ggsave("ba.pdf",p3,width = 14,height = 12)

