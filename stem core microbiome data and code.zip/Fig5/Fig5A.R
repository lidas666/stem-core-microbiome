

library(tidyr)
a<-read.csv("go_id_edg.csv")
a1<-subset(a, DEG == "Up")

a1<-a1[-2:-9]
names(a1)[1]<-c("query")

bayescan_enrichment_fg <- a1 %>%
  filter(! base::grepl("#", query) & GOs != "-") %>%
  select(GOs, query) %>%
  separate_rows(GOs, sep =",")


b<-read.csv("Goid.csv")
b1<-b
names(b1)[1]<-c("query")



bayescan_enrichment_bg <- b1

colnames(bayescan_enrichment_bg) <- c("query", "GOs")

bayescan_enrichment_bg <- tidyr::separate_rows(bayescan_enrichment_bg, GOs, sep = ",")

bayescan_enrichment_bg <- dplyr::select(bayescan_enrichment_bg, GOs, query)


c<-read.table("GO-transfered.txt", header = T, sep = "\t")

library(stringr)
term2name <- c %>%

  select(id, name, namespace) %>% unite(cat_name, namespace, name, sep = "_") %>%
  mutate(cat_name = str_replace_all(cat_name, "biological_process", "BP"),
         cat_name = str_replace_all(cat_name, "molecular_function", "MF"),
         cat_name = str_replace_all(cat_name, "cellular_component", "CC")) 

if (!require("BiocManager", quietly = TRUE))
  install.packages("BiocManager")
BiocManager::install("clusterProfiler")

library("clusterProfiler")
bayescan_enrichment <- enricher(
  gene = bayescan_enrichment_fg$query, 
  universe = bayescan_enrichment_bg$query, 
  TERM2GENE = bayescan_enrichment_bg, 
  TERM2NAME = term2name, 
  qvalueCutoff = 1, 
  pvalueCutoff = 1
)

enrichment_result <- bayescan_enrichment@result %>%
  separate(Description, into = c("Category", "Description"), sep = "_") %>%
  na.omit()%>%
  mutate(GeneRatioDecimal = eval(parse(text = GeneRatio)))
enrichment_plot <- enrichment_result %>% filter(p.adjust < 0.05)# %>%

write.csv(enrichment_plot,"enrichment__up.csv")

data<-enrichment_plot 

library(ggplot2)

custom_colors <- c("#fceb81","#bcea88","#4e81b9")


p <- ggplot(data, aes(x = Count, y =  reorder(Description, Count), fill = Category)) +
  geom_col(
    aes(fill = Category),
    position = position_dodge2(preserve = "single", width = 0.8),
    width = 0.7
  ) +
  geom_text(
    aes(label = Count),
    position = position_dodge2(width = 0.8),
    hjust = -0.2,
    size = 3.5
  ) +

  scale_x_continuous(
    expand = expansion(mult = c(0, 0.15))  
  ) +
  scale_fill_manual(values = custom_colors) +  
  labs(
    x = "No. of genes",
    y = "Description",
    fill = "Category"
  ) +
  theme_bw() +
  theme(axis.ticks.length = unit(0.4, "lines"), 
        axis.ticks = element_line(color = 'black'),
        axis.line = element_line(colour = "black"), 
        axis.title.x = element_text(size = 18, vjust = 1.5),
        axis.title.y = element_text(size = 18, vjust = 1.5),
        axis.text.y = element_text(size = 15),
        axis.text.x = element_text(size = 15,
                                   hjust = 1, vjust = 0.5))
p

ggsave("LD38 edg_up_GO.pdf",p,width =12,height = 6)
