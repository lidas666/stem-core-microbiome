

a<-read.csv("merg.csv")
a1<-a[2:7]
a1<-a1[-5]

library(tidyr)
library(dplyr)
library(pheatmap)

df<-a1
heatmap_data <- df %>%
  pivot_longer(cols = c(MF, BP, CC), 
               names_to = "Category", 
               values_to = "Value") %>%
  filter(Value == 1) %>%
  group_by(Category, Gene) %>%
  summarise(logFC = max(logFC), .groups = "drop") %>%
  pivot_wider(names_from = Gene, values_from = logFC) %>%
  as.data.frame() 

rownames(heatmap_data) <- heatmap_data$Category
heatmap_matrix <- as.matrix(heatmap_data[,-1])

colors <- colorRampPalette(c("#fceb81", "#acea88"))(100)

p<-pheatmap(heatmap_matrix,
         color = colors,
         na_col = "white",
         cluster_rows = FALSE,
         cluster_cols = FALSE,
         show_colnames = TRUE,
         main = "Gene Expression Heatmap",
         angle_col = 45)
ggsave("headmap.pdf",p,width = 9,height = 4)
