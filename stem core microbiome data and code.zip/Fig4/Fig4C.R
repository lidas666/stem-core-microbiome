

library(ggplot2)
library(reshape2)
library(vegan)
pacman::p_load(tidyverse,rio,reshape2,survminer,patchwork,agricolae,survival)

aa<-read.csv("IR.csv")

names(aa)[1]<-c("Group")

head(aa)

shapiro<-shapiro.test(aa$R)
shapiro
var<- var.test(R~Group,data=aa)
var

p1<-ggplot(data=aa, aes(x = Group, y = R,
                        color=Group)) +
  geom_boxplot(alpha =0.5,size=1,outlier.shape = NA)+
  scale_color_manual(limits=c("CK","PM"), 
                     values=c("#fceb81","#bcea88"))+
  stat_compare_means(method = "t.test",paired = T, 
                     comparisons=list(c("CK","PM")))+
  geom_jitter(size=0.5)+
  scale_y_continuous(expand = expansion(mult = c(0.05, 0.1)))+

  theme_bw(base_size = 16) +
  theme(axis.ticks.length = unit(0.4,"lines"), axis.ticks = element_line(color='black'),
        axis.line = element_line(colour = "black"), 
        axis.title.x=element_text(colour='black', size=20,vjust = 1.5),
        axis.title.y=element_text(colour='black', size=20,vjust = 1.5),
        axis.text.y=element_text(colour='black',size=18),
        axis.text.x=element_text(colour='black',size=18,angle = 90,hjust = 1),
        strip.text = element_text(colour = "black",size = 15,face = "bold"),
        legend.position = 'right')+
  labs(y='Radius')
p1
ggsave("IR__box.pdf",p1,width = 4,height = 4)



library(ggplot2)
library(reshape2)
library(vegan)
pacman::p_load(tidyverse, rio, reshape2, survminer, patchwork, agricolae, survival, ggsignif)

aa <- read.csv("IR.csv")

names(aa)[1] <- "Group"

head(aa)

shapiro <- shapiro.test(aa$R)
shapiro
var <- var.test(R ~ Group, data = aa)
var

p1 <- ggplot(data = aa, aes(x = Group, y = R, fill = Group)) +
  stat_summary(fun = mean, geom = "bar", position = position_dodge(width = 0.8), alpha = 0.7) +
  stat_summary(fun.data = mean_se, geom = "errorbar", position = position_dodge(width = 0.8), width = 0.2) +
  scale_fill_manual(limits = c("CK", "PM"), 
                    values = c("#fceb81", "#bcea88")) +
  ggsignif::geom_signif(
    comparisons = list(c("CK", "PM")),
    map_signif_level = TRUE,
    y_position = max(aa$R) * 1.1, 
    textsize = 5,
    vjust = 0.5
  ) +
  theme_bw(base_size = 16) +
  theme(
    axis.ticks.length = unit(0.4, "lines"),
    axis.ticks = element_line(color = 'black'),
    axis.line = element_line(colour = "black"), 
    axis.title.x = element_text(colour = 'black', size = 20, vjust = 1.5),
    axis.title.y = element_text(colour = 'black', size = 20, vjust = 1.5),
    axis.text.y = element_text(colour = 'black', size = 18),
    axis.text.x = element_text(colour = 'black', size = 18, angle = 90, hjust = 1),
    strip.text = element_text(colour = "black", size = 15, face = "bold"),
    legend.position = 'right'
  ) +
  labs(y = 'Radius', x = 'Group')

p1
ggsave("IR_BarPlot.pdf", p1, width = 4, height = 4)
