

m <- read.csv("rft25.csv")
library(ggplot2)
m <- m[order(m$MSE, decreasing = TRUE), ]

m$tax <- factor(m$tax, levels = unique(m$tax))
m$genus <- factor(m$Genus, levels = unique(m$Genus))
m$superclass <- factor(m$superclass, levels = unique(m$superclass))

# 定义颜色
cols <- c("#EFF7FC", "#E0F4FEFF", "#B2E5FCFF", "#80D3F9FF", "#4EC3F7FF",
          "#28B6F6FF", "#02A9F3FF", "#029AE5FF", "#0187D1FF", "#0177BDFF",
          "#006BB3", "#00548C", "#003D66")
cols <- c("#33A02C", "#aebea6","#266b69", "#FDBF6F","#ea894e", "#1F78B4", "#223e9c", "#999999","#eb4601", "#A6CEE3")


p <- ggplot(m, aes(x = tax, y = MSE, fill = superclass)) +
  geom_col(width = 0.7, alpha = 0.8) + 
  labs(title = NULL, x = NULL, y = 'Increase in MSE (%)', fill = 'Superclass') +
  theme(panel.grid = element_blank(), panel.background = element_blank(), 
        axis.line = element_line(colour = 'black')) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  scale_y_continuous(expand = c(0, 0), limit = c(0, 6)) +
  theme_bw(base_size = 16) +
  theme(axis.ticks.length = unit(0.4, "lines"), 
        axis.ticks = element_line(color = 'black'),
        axis.line = element_line(colour = "black"),
        axis.title.x = element_text(colour = 'black', size = 20, vjust = 1.5),
        axis.title.y = element_text(colour = 'black', size = 20, vjust = 1.5),
        axis.text.y = element_text(colour = 'black', size = 18),
        axis.text.x = element_text(colour = 'black', size = 12, angle = 90, hjust = 1),
        strip.text = element_text(colour = "black", size = 15, face = "bold"),
        legend.position = 'right') +  
  scale_fill_manual(values = cols) 

p <- p +
  geom_text(data = m, aes(x =tax, y = MSE, label = sig,size=12), position = "identity")

p

ggsave("RFtop25_2.pdf",p,width = 14,height =6)
