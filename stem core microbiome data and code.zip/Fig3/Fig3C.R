
library(ggplot2)


en<-read.csv("genrich.csv")
head(en)
p1<-ggplot(en,
       aes(y=Description,x=GeneRatio))+
  geom_point(aes(size=GeneRatio,color= - log(P)))+
  facet_grid(Ontology~., scale = 'free_y', space = 'free_y')+
  scale_color_gradient(low ="#c29f62" ,high ="#83ba9e")+
  labs(color=expression(PValue,size="Count"), 
       x="Gene Ratio",y="GO term",title="GO Enrichment")+
  theme_bw()+
  theme(axis.ticks.length = unit(0.4,"lines"), axis.ticks = element_line(color='black'),
        axis.line = element_line(), 
        axis.title.x=element_text(colour='black', size=20,vjust = 1.5),
        axis.title.y=element_text(colour='black', size=10,vjust = 1.5),
        axis.text.y=element_text(colour='black',size=10),
        axis.text.x=element_text(colour = "black",size = 18,
                                 angle = 0,hjust = 0.5,vjust = 0.5),
        strip.text = element_text(colour = "black",size = 18),
        legend.background = element_rect(fill = "transparent"))

p1
ggsave("GO富集图123.pdf",p1,width = 14, height =11)



library(ggplot2)

enn<-read.csv("合成菌群富集csv.csv")
enn<-enn[1:2]
ta<-read.csv("合成菌群富集注释.csv")

nw<-read.csv("nw.csv")
nw<-nw[-5:-10]

ww<-merge(enn,nw,by="ID")
ww<-ww[-2]

wh<-merge(ta,ww,by="ID")
wh1<-wh[-2:-4]
ta<-wh[1:4]
write.csv(wh1,"差异丰度.csv",row.names = F)
write.csv(ta,"差异丰度注释.csv",row.names = F)

w1<-wh1[1:30,]

rownames(w1)<-w1$ID
w1<-w1[-1]
mat <-t(w1)
mat <- as.matrix(mat)
mat1<-scale(mat)


t1<-ta[1:30,]
write.csv(t1,"30分类.csv")
rownames(t1)<-t1$ID
ann<-t1[2]
gene_anno <- as.matrix(ann)

group<-read.csv("Group.csv")
gr<-group[-4:-9,]
sample_group<-gr[2]
sample_group <- as.matrix(sample_group)



library(ComplexHeatmap)


Heatmap(
  mat1, name = 'gene',
  col = colorRampPalette(c('grey70', 'grey80', 'grey90', 'grey90', '#83ba9e','#83ac9e'))(100),
  cluster_rows = T, cluster_columns = F
)

